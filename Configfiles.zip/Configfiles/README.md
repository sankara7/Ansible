**How to Run**

To run use following Commands, 

$ docker-compose up -d 

once the containers build successfully, you can see the status using

$ docker ps

if any container is not running, please check the logs using to troubleshoot the issue. 

$ docker logs Container-name/container-ID
